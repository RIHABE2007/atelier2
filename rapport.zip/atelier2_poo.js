
// =========================
// Atelier 2 : Javascript et POO
// =========================

console.log("==== Exercice 1 ====");

// Exercice 1 : Voiture et héritage
class Voiture {
  constructor(model, marque, année, type, carburant) {
    this.model = model;
    this.marque = marque;
    this.année = année;
    this.type = type;
    this.carburant = carburant;
  }
}

class Hyundai extends Voiture {
  constructor(model, année, type, carburant, série, hybride) {
    super(model, "Hyundai", année, type, carburant);
    this.série = série;
    this.hybride = hybride;
  }

  alarmer() {
    console.log("Hyundai en alarme !");
  }
}

class Ford extends Voiture {
  constructor(model, année, type, carburant, options) {
    super(model, "Ford", année, type, carburant);
    this.options = options;
  }
}

let voitures = [
  new Hyundai("i30", 2020, "berline", "essence", "H30", true),
  new Ford("Mustang", 2018, "sport", "essence", ["GPS", "Clim", "Bluetooth"]),
  new Hyundai("Kona", 2022, "SUV", "électrique", "K20", true),
  new Ford("Fiesta", 2015, "compacte", "diesel", ["Bluetooth"]),
];

voitures.sort((a, b) => a.année - b.année);
voitures.forEach(v => console.log(`${v.marque} ${v.model} (${v.année})`));


console.log("\n==== Exercice 2 ====");

// Exercice 2 : Étudiant & Professeur
let etudiant = {
  nom: "Ali",
  prenom: "Karim",
  age: 20,
  cne: "CNE1234",
  etudier: function () {
    console.log(this.prenom + " étudie.");
  }
};

let professeur = {
  nom: "Ahmed",
  age: 45,
  cin: "CIN4567",
  enseigner: function () {
    console.log("Le professeur enseigne.");
  }
};

let liste = [etudiant, professeur];
liste.sort((a, b) => a.nom.localeCompare(b.nom) || a.prenom?.localeCompare(b.prenom) || a.age - b.age);
liste.forEach(p => console.log(p));


console.log("\n==== Exercice 3 ====");

// Exercice 3 : Vecteur2D et formes
class Vecteur2D {
  constructor(x = 0, y = 0) {
    this.x = x;
    this.y = y;
  }

  afficher() {
    console.log(`Vecteur(x=${this.x}, y=${this.y})`);
  }

  addition(v) {
    return new Vecteur2D(this.x + v.x, this.y + v.y);
  }
}

let v1 = new Vecteur2D();
let v2 = new Vecteur2D(3, 4);
v1.afficher();
v2.afficher();
v1.addition(v2).afficher();

class Rectangle {
  constructor(longueur = 1, largeur = 1) {
    this.nom = "rectangle";
    this.longueur = longueur;
    this.largeur = largeur;
  }

  afficher() {
    console.log(`${this.nom}: ${this.longueur} x ${this.largeur}`);
  }

  surface() {
    return this.longueur * this.largeur;
  }
}

class Carre extends Rectangle {
  constructor(côté = 1) {
    super(côté, côté);
    this.nom = "carré";
  }
}

let r = new Rectangle(3, 4);
let c = new Carre(5);
r.afficher();
console.log("Surface:", r.surface());
c.afficher();
console.log("Surface:", c.surface());

class Point {
  constructor(x = 0.0, y = 0.0) {
    this.x = x;
    this.y = y;
  }
}

class Segment {
  constructor(orig, extr) {
    this.orig = orig;
    this.extr = extr;
  }
}


console.log("\n==== Exercice 4 ====");

// Exercice 4 : Mini blog POO
class Post {
  constructor(title, description) {
    this.title = title;
    this.description = description;
  }
}

class User {
  constructor(nom, email) {
    this.nom = nom;
    this.email = email;
    this.posts = [];
  }

  ajouterPost(post) {
    this.posts.push(post);
  }
}

let users = [
  new User("Karim", "karim@mail.com"),
  new User("Nora", "nora@mail.com")
];

users[0].ajouterPost(new Post("Mon premier post", "Ceci est une description."));
console.log(JSON.stringify(users, null, 2));


console.log("\n==== Exercice 5 ====");

// Exercice 5 : Bibliothèque
let books = ["Le Petit Prince", "1984", "L'Étranger"];
books.push("Fahrenheit 451");
books.unshift("Les Misérables");
books.pop();
books.shift();
console.log("Livres:", books);

let categories = new Set(["Fiction", "Science", "Histoire"]);
categories.add("Biographie");
categories.add("Science");
categories.delete("Histoire");
console.log("Catégories:", categories);

let borrows = new Map();
borrows.set("Le Petit Prince", "Ali");
borrows.set("1984", "Sara");
borrows.set("L'Étranger", "Omar");
borrows.delete("1984");
console.log("Emprunts:", borrows);
console.log("Le Petit Prince emprunté ?", borrows.has("Le Petit Prince"));
